﻿import ollama
import chromadb
from chromadb.utils import embedding_functions

def main():
    # Ollamaの埋め込みモデルを使用
    emb_fn = embedding_functions.OllamaEmbeddingFunction(
        url="http://localhost:11434/api/embeddings",
        model_name="nomic-embed-text"
    )
    client = chromadb.PersistentClient(path="./my_db")
    collection = client.get_collection(name="documents", embedding_function=emb_fn)

    print("ナレッジベース準備完了！質問を入力してください。（'exit' で終了）\n")

    while True:
        user_query = input("\n質問 > ")
        if user_query.lower() in ["exit", "quit", "終了"]:
            print("対話を終了します。")
            break

        # 関連する上位3つのテキストブロックを自動抽出
        results = collection.query(
            query_texts=[user_query],
            n_results=3
        )

        retrieved_docs = results['documents'][0]
        sources = [m['source'] for m in results['metadatas'][0]]

        context = "\n---\n".join(retrieved_docs)
        source_list = ", ".join(set(sources))

        prompt = f"""以下の参照資料に基づいて日本語で回答してください。資料に内容がない場合は「記載がありません」と答えてください。

【参照資料】
{context}

【質問】
{user_query}
"""

        print(f"\n[参照元ファイル: {source_list}]")
        print("AIが思考中...")

        try:
            response = ollama.chat(
                model='gemma4:e4b',
                messages=[{'role': 'user', 'content': prompt}]
            )
            print(f"\n回答:\n{response['message']['content']}")
        except Exception as e:
            print(f"\nエラーが発生しました: {e}")

if __name__ == "__main__":
    main()