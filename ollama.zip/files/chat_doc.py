﻿import os
import ollama
import pdfplumber
import docx
import openpyxl

# --- ファイル読み込み処理 ---
def load_text_from_file(file_path):
    ext = os.path.splitext(file_path)[1].lower()
    text = ""
    
    if ext == ".pdf":
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                extracted = page.extract_text()
                if extracted:
                    text += extracted + "\n"
                    
    elif ext == ".docx":
        doc = docx.Document(file_path)
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
            
    elif ext in [".xlsx", ".xls"]:
        wb = openpyxl.load_workbook(file_path, data_only=True)
        for sheet in wb.sheetnames:
            ws = wb[sheet]
            text += f"--- シート: {sheet} ---\n"
            for row in ws.iter_rows(values_only=True):
                row_str = " | ".join([str(val) for val in row if val is not None])
                if row_str:
                    text += row_str + "\n"
                    
    elif ext in [".txt", ".csv"]:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
            
    else:
        raise ValueError(f"未対応のファイル形式です: {ext}")
        
    return text

# --- メイン対話処理 ---
def main():
    file_path = input("ファイルをドラッグ＆ドロップしてEnterを押してください: ").strip('"\' ')
    
    if not os.path.exists(file_path):
        print("指定されたファイルが見つかりません。")
        return

    print("ファイルを読み込んでいます...")
    try:
        file_content = load_text_from_file(file_path)
    except Exception as e:
        print(f"読み込みエラー: {e}")
        return

    print("読み込み完了！質問を入力してください。（'exit' で終了）\n")

    while True:
        user_query = input("\n質問 > ")
        if user_query.lower() in ["exit", "quit", "終了"]:
            print("対話を終了します。")
            break

        prompt = f"""以下の資料に基づいて日本語で回答してください。資料にない内容は「記載がありません」と答えてください。

【資料内容】
{file_content}

【質問】
{user_query}
"""

        print("\nAIが思考中...")
        try:
            response = ollama.chat(
                model='gemma4:e4b',
                messages=[{'role': 'user', 'content': prompt}]
            )
            print(f"\n回答:\n{response['message']['content']}")
        except Exception as e:
            print(f"\nエラーが発生しました。Ollamaが起動しているか確認してください: {e}")

if __name__ == "__main__":
    main()