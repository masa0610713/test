﻿import re
import logging
from mitmproxy import http

# ログ設定
logging.basicConfig(
    filename='leak_monitor.log',
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)

# NGワードリストの読み込み
def load_ng_words(filepath='ngword.txt'):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print(f"[!] {filepath} が見つかりません。空のリストで開始します。")
        return []

NG_WORDS = load_ng_words()

class LeakBlocker:
    def request(self, flow: http.HTTPFlow) -> None:
        client_ip = flow.client_conn.peername[0] if flow.client_conn.peername else "Unknown"
        host = flow.request.pretty_host
        
        # 1. POST/PUTなどのデータ送信時の処理
        if flow.request.method in ["POST", "PUT", "PATCH"]:
            content_type = flow.request.headers.get("Content-Type", "")
            
            # --- A. ファイル送信の検知 & ブロック ---
            if "multipart/form-data" in content_type:
                filename_match = re.search(r'filename="([^"]+)"', flow.request.text)
                filename = filename_match.group(1) if filename_match else "Unknown File"
                
                log_msg = f"[FILE_BLOCKED] Source: {client_ip} -> Host: {host} | File: {filename}"
                print(f"\033[91m{log_msg}\033[0m")
                logging.warning(log_msg)
                
                # 通信を強制ブロック（403応答を返す）
                self.block_request(flow, f"File transfer ({filename}) blocked by security policy.")
                return

            # --- B. NGワードの検知 & ブロック ---
            request_text = flow.request.get_text(strict=False)
            for word in NG_WORDS:
                if word in request_text:
                    log_msg = f"[NG_WORD_BLOCKED] Source: {client_ip} -> Host: {host} | Keyword: {word}"
                    print(f"\033[91m{log_msg}\033[0m")
                    logging.warning(log_msg)
                    
                    # 通信を強制ブロック（403応答を返す）
                    self.block_request(flow, f"Content contains blocked keyword: '{word}'")
                    return

    def block_request(self, flow: http.HTTPFlow, reason: str):
        """リクエストをサーバーに送信せず、クライアントにエラーレスポンスを返す"""
        flow.response = http.Response.make(
            403,  # HTTPステータスコード 403 Forbidden
            f"<h1>403 Forbidden - Security Policy Violation</h1><p>{reason}</p>".encode('utf-8'),
            {"Content-Type": "text/html; charset=utf-8"}
        )

addons = [
    LeakBlocker()
]