﻿import os
import re
from datetime import datetime
from urllib.parse import parse_qs
from mitmproxy import http

# 設定
LOG_FILE = "leak_monitor.log"
NGWORD_FILE = "ngword.txt"

def load_ngwords():
    """ngword.txt から監視対象文字列を読み込む"""
    if not os.path.exists(NGWORD_FILE):
        return []
    with open(NGWORD_FILE, "r", encoding="utf-8", errors="ignore") as f:
        return [line.strip() for line in f if line.strip()]

def write_log(event_type, src_ip, dst_ip, detail):
    """ログファイルへの追記出力"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] [{event_type}] Source: {src_ip} -> Dest: {dst_ip} | {detail}\n"
    
    # 画面とファイルの両方に出力
    print(f"\033[91m{log_entry.strip()}\033[0m")  # 赤字でコンソール強調
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(log_entry)

def request(flow: http.HTTPFlow) -> None:
    """HTTP/HTTPS リクエスト送信時の処理"""
    # POST / PUT などのデータ送信リクエストのみを解析
    if flow.request.method not in ["POST", "PUT", "PATCH"]:
        return

    src_ip = flow.client_conn.peername[0] if flow.client_conn.peername else "127.0.0.1"
    dst_ip = flow.server_conn.peername[0] if flow.server_conn.peername else "Unknown"
    
    ng_words = load_ngwords()

    # 1. マルチパートフォームデータ（ファイルアップロード等）の解析
    if "multipart/form-data" in flow.request.headers.get("content-type", ""):
        # ファイル名の検出
        filenames = re.findall(r'filename="([^"]+)"', flow.request.text)
        for fname in filenames:
            write_log("FILE_TRANSFER", src_ip, dst_ip, f"File: {fname}")

    # 2. テキスト・送信データのNGワード検出
    body_text = flow.request.get_text(strict=False)
    if body_text:
        for word in ng_words:
            if word in body_text:
                write_log("NG_WORD_DETECTED", src_ip, dst_ip, f"Keyword: {word}")