﻿import os
import glob
import pdfplumber
import docx
import openpyxl
import chromadb
from chromadb.utils import embedding_functions

def load_text(file_path):
    ext = os.path.splitext(file_path)[1].lower()
    text = ""
    try:
        if ext == ".pdf":
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    t = page.extract_text()
                    if t: text += t + "\n"
        elif ext == ".docx":
            doc = docx.Document(file_path)
            for p in doc.paragraphs:
                text += p.text + "\n"
        elif ext in [".xlsx", ".xls"]:
            wb = openpyxl.load_workbook(file_path, data_only=True)
            for sheet in wb.sheetnames:
                for row in wb[sheet].iter_rows(values_only=True):
                    row_str = " | ".join([str(v) for v in row if v is not None])
                    if row_str: text += row_str + "\n"
        elif ext in [".txt", ".csv"]:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
    except Exception as e:
        print(f"読み込みエラー ({file_path}): {e}")
    return text

def split_text(text, chunk_size=500, overlap=100):
    chunks = []
    for i in range(0, len(text), chunk_size - overlap):
        chunks.append(text[i:i + chunk_size])
    return chunks

def main():
    folder_path = input("資料が入っているフォルダのパスを入力してください: ").strip('"\' ')
    if not os.path.exists(folder_path):
        print("指定されたフォルダが存在しません。")
        return

    # Ollamaの埋め込みモデルを使用
    emb_fn = embedding_functions.OllamaEmbeddingFunction(
        url="http://localhost:11434/api/embeddings",
        model_name="nomic-embed-text"
    )

    client = chromadb.PersistentClient(path="./my_db")
    collection = client.get_or_create_collection(name="documents", embedding_function=emb_fn)

    print("\nドキュメントの解析とデータベース構築を開始します...")
    
    files = glob.glob(os.path.join(folder_path, "**/*.*"), recursive=True)
    doc_id = 0

    for file_path in files:
        filename = os.path.basename(file_path)
        print(f"処理中: {filename}")
        content = load_text(file_path)
        if not content.strip():
            continue

        chunks = split_text(content)
        for chunk in chunks:
            collection.add(
                documents=[chunk],
                metadatas=[{"source": filename}],
                ids=[f"id_{doc_id}"]
            )
            doc_id += 1

    print(f"\n完了！ {doc_id} 個のテキストブロックをデータベース（./my_db）に保存しました。")

if __name__ == "__main__":
    main()