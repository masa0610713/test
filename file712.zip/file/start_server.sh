#!/bin/bash
# Simple server for LM Chat application with CGI support
# Navigate to the directory containing this script and start a Python HTTP server with CGI handling
cd "$(dirname "$0")"
# Use port 8002 (avoid conflicts)
python3 server.py 8000
