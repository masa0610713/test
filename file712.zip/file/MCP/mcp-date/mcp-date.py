from mcp.server.fastmcp import FastMCP
import subprocess

# ツールセットの名前を定義
mcp = FastMCP("LocalRunner")

@mcp.tool()
def execute_command(command: str) -> str:
    """ローカルのシェルコマンド（date, ls等）を実行して結果を返します。"""
    try:
        # コマンドを実行し、結果を取得
        return subprocess.check_output(command, shell=True, text=True).strip()
    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == "__main__":
    mcp.run()
