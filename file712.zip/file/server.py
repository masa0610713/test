#!/usr/bin/env python3
import sys
import os
import subprocess
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler

class SafeCGIHTTPRequestHandler(SimpleHTTPRequestHandler):
    def do_POST(self):
        if self.path.startswith('/cgi-bin/'):
            self.run_cgi_safe()
        else:
            super().do_POST()
            
    def do_GET(self):
        if self.path.startswith('/cgi-bin/'):
            self.run_cgi_safe()
        else:
            super().do_GET()

    def run_cgi_safe(self):
        # 1. Prepare environment variables for the CGI script
        env = os.environ.copy()
        env['REQUEST_METHOD'] = self.command
        env['SCRIPT_NAME'] = self.path
        env['PATH_INFO'] = self.path
        
        # Read content-length and headers
        content_length = int(self.headers.get('Content-Length', 0))
        env['CONTENT_LENGTH'] = str(content_length)
        if 'Content-Type' in self.headers:
            env['CONTENT_TYPE'] = self.headers['Content-Type']
            
        # Get query string if present
        if '?' in self.path:
            env['QUERY_STRING'] = self.path.split('?', 1)[1]
        else:
            env['QUERY_STRING'] = ''
            
        # 2. Get script path
        script_name = self.path.split('?')[0]
        script_path = '.' + script_name
        if not os.path.exists(script_path):
            self.send_error(404, f"CGI script not found: {script_name}")
            return
            
        # Read POST body from input socket if content_length > 0
        post_data = b""
        if content_length > 0:
            try:
                post_data = self.rfile.read(content_length)
            except Exception as re:
                sys.stderr.write(f"[ERROR] Failed to read request body: {str(re)}\n")
                sys.stderr.flush()
                self.send_error(400, "Bad Request: Failed to read body")
                return
            
        # 3. Spawn subprocess using subprocess.Popen (Thread-safe, no os.fork debug warnings)
        cmd = ["python3", "-u", script_path]
        
        try:
            proc = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env
            )
            
            # Send POST data if any
            if post_data:
                proc.stdin.write(post_data)
            proc.stdin.close()
            
            # Parse HTTP response headers from CGI output line by line
            header_lines = []
            while True:
                line = proc.stdout.readline()
                if not line:
                    break
                # CGI headers end with an empty line
                if line == b'\n' or line == b'\r\n':
                    break
                header_lines.append(line)
            
            # Parse headers and send response
            self.send_response(200)
            
            # Send response headers back to client
            has_content_length = False
            for line in header_lines:
                if b':' in line:
                    k, v = line.split(b':', 1)
                    key_str = k.decode('utf-8').strip()
                    val_str = v.decode('utf-8').strip()
                    if key_str.lower() == 'content-length':
                        has_content_length = True
                    self.send_header(key_str, val_str)
            
            # Note: We do NOT set Content-Length if it was not provided by CGI (especially for SSE)
            self.end_headers()
            
            # Stream the body content back to client in real-time
            try:
                while True:
                    chunk = proc.stdout.read(1024)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    self.wfile.flush()
            except (ConnectionResetError, BrokenPipeError) as se:
                sys.stderr.write(f"[INFO] Client disconnected during CGI streaming: {str(se)}\n")
                sys.stderr.flush()
            
            # Wait for the process to terminate and read stderr
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
            
            stderr_data = proc.stderr.read()
            if stderr_data:
                sys.stderr.write(f"[CGI STDERR] {script_name}:\n{stderr_data.decode('utf-8', errors='replace')}\n")
                sys.stderr.flush()
                
        except subprocess.TimeoutExpired:
            proc.kill()
            sys.stderr.write(f"[ERROR] CGI script timeout: {script_name}\n")
            sys.stderr.flush()
            try:
                self.send_error(504, "Gateway Timeout: CGI script execution timed out")
            except Exception:
                pass
        except Exception as e:
            sys.stderr.write(f"[ERROR] CGI execution failed: {str(e)}\n")
            sys.stderr.flush()
            try:
                self.send_error(500, f"Internal Server Error: CGI execution failed: {str(e)}")
            except Exception:
                pass

    def log_message(self, format, *args):
        # Forward requests logs to stderr so we can track in task logs
        sys.stderr.write("%s - - [%s] %s\n" %
                         (self.client_address[0],
                          self.log_date_time_string(),
                          format%args))
        sys.stderr.flush()

def init_database():
    db_file = os.path.abspath(os.path.join(os.path.dirname(__file__), 'chat.db'))
    import sqlite3
    conn = sqlite3.connect(db_file, timeout=30.0)
    conn.execute("PRAGMA journal_mode = WAL")
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS conversations (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        conversation_id TEXT NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
    )
    """)
    conn.commit()
    conn.close()

def run(port=8000):
    init_database()
    server_address = ('', port)
    # ThreadingHTTPServer automatically spawns a thread for each incoming connection
    httpd = ThreadingHTTPServer(server_address, SafeCGIHTTPRequestHandler)
    sys.stderr.write(f"[INFO] Concurrent Safe CGI Server starting on port {port}...\n")
    sys.stderr.flush()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        sys.stderr.write("\n[INFO] Server shutting down.\n")
        sys.stderr.flush()
        httpd.server_close()

if __name__ == '__main__':
    main_port = 8000
    if len(sys.argv) > 1:
        try:
            main_port = int(sys.argv[1])
        except ValueError:
            pass
    run(main_port)
